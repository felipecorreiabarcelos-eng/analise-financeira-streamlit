"""
app_streamlit.py — Dashboard Financeiro Interativo
Execute com: streamlit run app_streamlit.py
"""

import streamlit as st
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import io
import warnings
warnings.filterwarnings('ignore')

# Importa funções do módulo principal
from relatorio_financeiro import gerar_dados_csv, processar_dados, exportar_pdf

# ─── Configuração da página ──────────────────
st.set_page_config(
    page_title="Relatório Financeiro 2024",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── CSS customizado ─────────────────────────
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        border-left: 4px solid #2E86AB;
        border-radius: 8px;
        padding: 16px 20px;
        margin-bottom: 8px;
    }
    .metric-label { font-size: 12px; color: #666; font-weight: 600; text-transform: uppercase; }
    .metric-value { font-size: 22px; color: #1a1a2e; font-weight: 700; }
    .stDownloadButton > button {
        background-color: #2E86AB;
        color: white;
        border-radius: 6px;
        border: none;
        font-weight: 600;
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)


# ─── Sidebar / Controles ─────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/color/96/combo-chart.png", width=60)
    st.title("⚙️ Configurações")
    st.divider()

    seed = st.number_input("Semente aleatória", min_value=1, max_value=9999, value=42)
    categorias_sel = st.multiselect(
        "Filtrar categorias",
        ["Eletrônicos", "Software", "Serviços"],
        default=["Eletrônicos", "Software", "Serviços"],
    )
    periodo = st.select_slider(
        "Período (meses)",
        options=list(range(1, 13)),
        value=(1, 12),
    )
    st.divider()
    gerar_btn = st.button("🔄 Gerar / Atualizar Dados", use_container_width=True)


# ─── Cache dos dados ──────────────────────────
@st.cache_data(show_spinner=False)
def carregar_dados(seed_val):
    df = gerar_dados_csv("vendas_mensais.csv", seed=seed_val)
    return df


# ─── Lógica principal ─────────────────────────
if "df_raw" not in st.session_state or gerar_btn:
    with st.spinner("Gerando dados e calculando KPIs..."):
        st.session_state["df_raw"] = carregar_dados.clear() or carregar_dados(seed)

df_raw = st.session_state["df_raw"]

# Aplicar filtros
df_filtrado = df_raw[
    (df_raw["Categoria"].isin(categorias_sel)) &
    (df_raw["Data"].dt.month >= periodo[0]) &
    (df_raw["Data"].dt.month <= periodo[1])
].copy()

if df_filtrado.empty:
    st.warning("Nenhum dado encontrado com os filtros selecionados.")
    st.stop()

kpis = processar_dados(df_filtrado)


# ─── Título ──────────────────────────────────
st.title("📊 Dashboard Financeiro 2024")
st.caption(f"Exibindo {len(df_filtrado):,} registros · Período: {periodo[0]:02d}/2024 → {periodo[1]:02d}/2024")
st.divider()


# ─── KPI Cards ───────────────────────────────
c1, c2, c3, c4 = st.columns(4)

with c1:
    st.metric("💰 Faturamento Total", f"R$ {kpis['faturamento_total']:,.0f}")
with c2:
    st.metric("📦 Custo Total", f"R$ {kpis['custo_total']:,.0f}")
with c3:
    delta = kpis['lucro_total'] - kpis['custo_total']
    st.metric("📈 Lucro Total", f"R$ {kpis['lucro_total']:,.0f}")
with c4:
    st.metric("🎯 Margem Geral", f"{kpis['margem_geral']:.1f}%")

st.divider()


# ─── Gráficos lado a lado ────────────────────
col_esq, col_dir = st.columns(2)

with col_esq:
    st.subheader("📦 Lucro por Categoria")

    fig, ax = plt.subplots(figsize=(6, 4))
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F8F9FA")
    cores = ["#2E86AB", "#A23B72", "#F18F01"]
    cat_df = kpis["categoria_df"]

    bars = ax.bar(cat_df["Categoria"], cat_df["Lucro_Total"] / 1_000,
                  color=cores[:len(cat_df)], width=0.5, edgecolor="white", linewidth=1.5)
    for bar, m in zip(bars, cat_df["Margem_Pct"]):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 8,
                f"{m:.1f}%", ha="center", fontsize=8, color="#444")

    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"R${x:,.0f}k"))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

with col_dir:
    st.subheader("📈 Evolução Mensal")

    fig2, ax2 = plt.subplots(figsize=(6, 4))
    fig2.patch.set_facecolor("#F8F9FA")
    ax2.set_facecolor("#F8F9FA")
    m_df = kpis["mensal_df"]
    x    = range(len(m_df))

    ax2.plot(x, m_df["Faturamento"] / 1_000, marker="o", color="#2E86AB",
             linewidth=2, markersize=5, label="Faturamento")
    ax2.plot(x, m_df["Lucro"] / 1_000, marker="s", color="#F18F01",
             linewidth=2, markersize=5, label="Lucro")
    ax2.fill_between(x, m_df["Faturamento"] / 1_000, m_df["Lucro"] / 1_000,
                     alpha=0.07, color="#2E86AB")
    ax2.set_xticks(x)
    ax2.set_xticklabels(m_df["MesStr"], rotation=45, ha="right", fontsize=7)
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"R${v:,.0f}k"))
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.grid(linestyle="--", alpha=0.35)
    ax2.legend(fontsize=9)
    plt.tight_layout()
    st.pyplot(fig2)
    plt.close()


# ─── Tabela de categorias ────────────────────
st.divider()
st.subheader("📋 Detalhamento por Categoria")

display_df = kpis["categoria_df"].copy()
display_df["Faturamento"] = display_df["Faturamento"].map("R$ {:,.2f}".format)
display_df["Custo_Total"] = display_df["Custo_Total"].map("R$ {:,.2f}".format)
display_df["Lucro_Total"] = display_df["Lucro_Total"].map("R$ {:,.2f}".format)
display_df["Margem_Pct"]  = display_df["Margem_Pct"].map("{:.1f}%".format)
display_df.rename(columns={
    "Faturamento": "Faturamento (R$)",
    "Custo_Total": "Custo (R$)",
    "Lucro_Total": "Lucro (R$)",
    "Margem_Pct":  "Margem %",
    "Qtd_Vendas":  "Qtd. Vendas",
}, inplace=True)
st.dataframe(display_df, use_container_width=True, hide_index=True)


# ─── Download PDF ────────────────────────────
st.divider()
st.subheader("⬇️ Exportar Relatório")

if st.button("📄 Gerar PDF e Baixar"):
    with st.spinner("Gerando PDF..."):
        import tempfile, os
        with tempfile.TemporaryDirectory() as tmpdir:
            img_b = os.path.join(tmpdir, "barras.png")
            img_l = os.path.join(tmpdir, "linhas.png")
            pdf_p = os.path.join(tmpdir, "relatorio.pdf")

            from relatorio_financeiro import criar_grafico_barras, criar_grafico_linhas
            criar_grafico_barras(kpis["categoria_df"], img_b)
            criar_grafico_linhas(kpis["mensal_df"], img_l)
            exportar_pdf(kpis, img_b, img_l, pdf_p)

            with open(pdf_p, "rb") as f:
                pdf_bytes = f.read()

    st.download_button(
        label="📥 Clique para Baixar o PDF",
        data=pdf_bytes,
        file_name="relatorio_financeiro_2024.pdf",
        mime="application/pdf",
    )
    st.success("PDF gerado com sucesso!")


# ─── Rodapé ──────────────────────────────────
st.divider()
st.caption("📊 Dashboard Financeiro · Desenvolvido com Python, Pandas, Matplotlib & Streamlit")
