# 📊 Automação de Relatórios Financeiros

> Pipeline Python completo que extrai, processa e apresenta dados financeiros em PDF e em uma aplicação web interativa.

---

## 🎯 O Problema que Este Projeto Resolve

Equipes financeiras frequentemente gastam horas toda semana consolidando dados em planilhas, copiando gráficos manualmente e formatando relatórios em PDF — um processo repetitivo, sujeito a erros e de baixo valor agregado.

Este projeto **automatiza todo esse fluxo em segundos**:
1. Lê os dados brutos de vendas (CSV)
2. Calcula KPIs financeiros: lucro, margem por categoria, produto mais vendido
3. Gera gráficos profissionais automaticamente
4. Exporta um relatório PDF pronto para apresentação — ou exibe tudo em um dashboard web interativo

---

## 🚀 Funcionalidades

| Feature | Descrição |
|---|---|
| 📥 **Ingestão de Dados** | Leitura de CSV com Pandas + geração de dados fictícios para demo |
| 📐 **KPIs Automáticos** | Lucro total, margem por categoria, produto líder em faturamento |
| 📊 **Visualizações** | Gráfico de barras (lucro/categoria) + linha (evolução mensal) |
| 📄 **Relatório PDF** | Layout profissional com tabelas, insights e gráficos via FPDF2 |
| 🌐 **Dashboard Web** | App Streamlit com filtros interativos e download do PDF |

---

## 🛠️ Tecnologias Utilizadas

- **Python 3.11+**
- **Pandas** — Manipulação e agregação dos dados financeiros
- **NumPy** — Geração de dados aleatórios realistas
- **Matplotlib** — Criação dos gráficos de barras e linhas
- **Seaborn** — Estilo e paleta dos gráficos
- **FPDF2** — Composição e exportação do relatório em PDF
- **Streamlit** — Interface web interativa com filtros e download

---

## ⚙️ Como Executar

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/relatorio-financeiro.git
cd relatorio-financeiro
```

### 2. Instale as dependências
```bash
pip install -r requirements.txt
```

### 3. Gere o relatório PDF (modo script)
```bash
python relatorio_financeiro.py
```
→ Cria `vendas_mensais.csv`, os gráficos `.png` e o `relatorio_financeiro.pdf`

### 4. Rode o dashboard interativo (modo web)
```bash
streamlit run app_streamlit.py
```
→ Abre no navegador em `http://localhost:8501`

---

## 📁 Estrutura do Projeto

```
relatorio-financeiro/
├── relatorio_financeiro.py   # Pipeline principal (dados → PDF)
├── app_streamlit.py          # Dashboard web interativo
├── requirements.txt          # Dependências do projeto
└── README.md
```

---

## 📸 Preview

### Relatório PDF
- Página 1: KPIs executivos + tabela de desempenho por categoria + insights
- Página 2: Gráfico de barras + gráfico de linha temporal

### Dashboard Streamlit
- Sidebar com filtros de categoria e período
- Cards de KPIs em tempo real
- Gráficos interativos lado a lado
- Botão de download do PDF gerado dinamicamente

---

## 💡 Possíveis Extensões

- [ ] Conectar a uma fonte de dados real (Google Sheets, banco SQL, API REST)
- [ ] Adicionar agendamento automático com `schedule` ou Apache Airflow
- [ ] Envio automático do PDF por e-mail com `smtplib`
- [ ] Deploy do dashboard no Streamlit Community Cloud (gratuito)
- [ ] Alertas automáticos quando a margem cair abaixo de um threshold

---

## 👨‍💻 Autor

Desenvolvido como projeto de portfólio para demonstrar habilidades em:
**Automação com Python · Análise de Dados · Visualização · Engenharia de Relatórios**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=flat&logo=linkedin)](https://linkedin.com/in/seu-perfil)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-black?style=flat&logo=github)](https://github.com/seu-usuario)
