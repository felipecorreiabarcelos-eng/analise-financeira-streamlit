"""
Automação de Relatórios Financeiros
Autor: Portfólio - Desenvolvedor Python
Descrição: Gera dados fictícios de vendas, processa KPIs financeiros
            e exporta um relatório completo em PDF com gráficos.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
from fpdf import FPDF
from datetime import datetime
import os
import warnings
warnings.filterwarnings('ignore')


# ─────────────────────────────────────────────
# 1. GERAÇÃO DE DADOS FICTÍCIOS
# ─────────────────────────────────────────────

def gerar_dados_csv(caminho: str = "vendas_mensais.csv", seed: int = 42) -> pd.DataFrame:
    """Gera um CSV fictício de vendas mensais e retorna o DataFrame."""
    np.random.seed(seed)

    produtos = {
        "Eletrônicos": ["Notebook Pro", "Monitor 4K", "Teclado Mecânico", "Webcam HD"],
        "Software":    ["Suite Office", "Antivírus Plus", "ERP Starter", "Design Pro"],
        "Serviços":    ["Consultoria TI", "Suporte Mensal", "Treinamento", "Implementação"],
    }

    registros = []
    datas = pd.date_range(start="2024-01-01", end="2024-12-31", freq="D")

    for data in datas:
        n_vendas = np.random.randint(2, 8)
        for _ in range(n_vendas):
            categoria = np.random.choice(list(produtos.keys()))
            produto   = np.random.choice(produtos[categoria])

            # Faixas de preço realistas por categoria
            faixas = {
                "Eletrônicos": (1_200, 8_500),
                "Software":    (  300, 3_200),
                "Serviços":    (  800, 6_000),
            }
            valor = round(np.random.uniform(*faixas[categoria]), 2)

            # Margem de custo varia por categoria
            pct_custo = {
                "Eletrônicos": np.random.uniform(0.55, 0.75),
                "Software":    np.random.uniform(0.20, 0.35),
                "Serviços":    np.random.uniform(0.40, 0.60),
            }[categoria]

            custo = round(valor * pct_custo, 2)
            registros.append([data, produto, categoria, valor, custo])

    df = pd.DataFrame(registros, columns=["Data", "Produto", "Categoria", "Valor_Venda", "Custo"])
    df["Data"] = pd.to_datetime(df["Data"])
    df.to_csv(caminho, index=False, encoding="utf-8-sig")
    print(f"[✔] CSV gerado: {caminho}  ({len(df):,} registros)")
    return df


# ─────────────────────────────────────────────
# 2. PROCESSAMENTO E KPIs
# ─────────────────────────────────────────────

def processar_dados(df: pd.DataFrame) -> dict:
    """Calcula KPIs financeiros e retorna dicionário com os resultados."""
    df = df.copy()
    df["Lucro"]  = df["Valor_Venda"] - df["Custo"]
    df["Mes"]    = df["Data"].dt.to_period("M")
    df["MesStr"] = df["Data"].dt.strftime("%b/%Y")

    # KPIs gerais
    faturamento_total = df["Valor_Venda"].sum()
    custo_total       = df["Custo"].sum()
    lucro_total       = df["Lucro"].sum()
    margem_geral      = (lucro_total / faturamento_total) * 100

    # Por categoria
    categoria_df = (
        df.groupby("Categoria")
          .agg(Faturamento=("Valor_Venda", "sum"),
               Custo_Total=("Custo", "sum"),
               Lucro_Total=("Lucro", "sum"),
               Qtd_Vendas=("Lucro", "count"))
          .assign(Margem_Pct=lambda x: (x["Lucro_Total"] / x["Faturamento"]) * 100)
          .sort_values("Lucro_Total", ascending=False)
          .reset_index()
    )

    # Produto mais vendido (por faturamento)
    produto_top = (
        df.groupby("Produto")["Valor_Venda"]
          .sum()
          .idxmax()
    )
    produto_top_valor = df.groupby("Produto")["Valor_Venda"].sum().max()

    # Evolução mensal
    mensal_df = (
        df.groupby(["Mes", "MesStr"])
          .agg(Faturamento=("Valor_Venda", "sum"),
               Lucro=("Lucro", "sum"))
          .reset_index()
          .sort_values("Mes")
    )

    print(f"[✔] Processamento concluído — Lucro Total: R$ {lucro_total:,.2f}")

    return {
        "df":                  df,
        "faturamento_total":   faturamento_total,
        "custo_total":         custo_total,
        "lucro_total":         lucro_total,
        "margem_geral":        margem_geral,
        "categoria_df":        categoria_df,
        "produto_top":         produto_top,
        "produto_top_valor":   produto_top_valor,
        "mensal_df":           mensal_df,
    }


# ─────────────────────────────────────────────
# 3. VISUALIZAÇÕES
# ─────────────────────────────────────────────

def criar_grafico_barras(categoria_df: pd.DataFrame, caminho: str = "grafico_barras.png") -> str:
    """Gráfico de barras: Lucro por Categoria."""
    cores = ["#2E86AB", "#A23B72", "#F18F01"]

    fig, ax = plt.subplots(figsize=(9, 5.5))
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F8F9FA")

    bars = ax.bar(
        categoria_df["Categoria"],
        categoria_df["Lucro_Total"] / 1_000,
        color=cores[:len(categoria_df)],
        width=0.5,
        edgecolor="white",
        linewidth=1.5,
    )

    # Rótulos nas barras
    for bar, margem in zip(bars, categoria_df["Margem_Pct"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 15,
            f"Margem: {margem:.1f}%",
            ha="center", va="bottom", fontsize=9, color="#444",
        )

    ax.set_title("Lucro Total por Categoria (2024)", fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel("Categoria", fontsize=11)
    ax.set_ylabel("Lucro (R$ mil)", fontsize=11)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"R$ {x:,.0f}k"))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(caminho, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[✔] Gráfico de barras salvo: {caminho}")
    return caminho


def criar_grafico_linhas(mensal_df: pd.DataFrame, caminho: str = "grafico_linhas.png") -> str:
    """Gráfico de linhas: Evolução de Faturamento e Lucro mensais."""
    fig, ax = plt.subplots(figsize=(11, 5.5))
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F8F9FA")

    meses = mensal_df["MesStr"]
    x     = range(len(meses))

    ax.plot(x, mensal_df["Faturamento"] / 1_000, marker="o", color="#2E86AB",
            linewidth=2.2, markersize=6, label="Faturamento")
    ax.plot(x, mensal_df["Lucro"] / 1_000, marker="s", color="#F18F01",
            linewidth=2.2, markersize=6, label="Lucro")

    ax.fill_between(x, mensal_df["Faturamento"] / 1_000, mensal_df["Lucro"] / 1_000,
                    alpha=0.08, color="#2E86AB")

    ax.set_xticks(x)
    ax.set_xticklabels(meses, rotation=45, ha="right", fontsize=8)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"R$ {v:,.0f}k"))
    ax.set_title("Evolução Mensal de Faturamento e Lucro (2024)", fontsize=14, fontweight="bold", pad=15)
    ax.set_ylabel("Valor (R$ mil)", fontsize=11)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(linestyle="--", alpha=0.35)
    ax.legend(fontsize=10)
    plt.tight_layout()
    plt.savefig(caminho, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[✔] Gráfico de linhas salvo: {caminho}")
    return caminho


# ─────────────────────────────────────────────
# 4. EXPORTAÇÃO EM PDF
# ─────────────────────────────────────────────

class RelatorioPDF(FPDF):
    """Classe PDF personalizada com cabeçalho e rodapé."""

    def header(self):
        self.set_fill_color(46, 134, 171)   # #2E86AB
        self.rect(0, 0, 210, 18, "F")
        self.set_font("Helvetica", "B", 13)
        self.set_text_color(255, 255, 255)
        self.set_xy(0, 3)
        self.cell(210, 12, "RELATÓRIO FINANCEIRO — 2024", align="C")
        self.set_text_color(0, 0, 0)
        self.ln(14)

    def footer(self):
        self.set_y(-14)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(130, 130, 130)
        self.cell(0, 10, f"Gerado em {datetime.now().strftime('%d/%m/%Y %H:%M')}  |  Página {self.page_no()}", align="C")


def exportar_pdf(kpis: dict, img_barras: str, img_linhas: str,
                 caminho: str = "relatorio_financeiro.pdf") -> str:
    """Monta e exporta o relatório PDF completo."""
    pdf = RelatorioPDF()
    pdf.set_auto_page_break(auto=True, margin=20)
    pdf.add_page()

    # ── Resumo Executivo ──
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(46, 134, 171)
    pdf.cell(0, 8, "RESUMO EXECUTIVO", ln=True)
    pdf.set_draw_color(46, 134, 171)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)

    def kpi_box(label: str, valor: str, x: float, y: float, w: float = 56):
        pdf.set_xy(x, y)
        pdf.set_fill_color(240, 247, 252)
        pdf.rect(x, y, w, 20, "F")
        pdf.set_font("Helvetica", "", 8)
        pdf.set_text_color(100, 100, 100)
        pdf.set_xy(x + 2, y + 2)
        pdf.cell(w - 4, 5, label)
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(30, 30, 30)
        pdf.set_xy(x + 2, y + 8)
        pdf.cell(w - 4, 8, valor)

    y_kpi = pdf.get_y()
    kpi_box("💰 Faturamento Total",  f"R$ {kpis['faturamento_total']:>12,.2f}", 10,  y_kpi)
    kpi_box("📦 Custo Total",        f"R$ {kpis['custo_total']:>12,.2f}",       70,  y_kpi)
    kpi_box("📈 Lucro Total",        f"R$ {kpis['lucro_total']:>12,.2f}",       130, y_kpi)
    pdf.ln(28)

    kpi_box("🎯 Margem Geral",       f"{kpis['margem_geral']:.1f}%",            10, pdf.get_y(), 84)
    kpi_box("🏆 Produto Mais Vendido", kpis['produto_top'][:22],                98, pdf.get_y(), 102)
    pdf.ln(28)

    # ── KPIs por Categoria ──
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(46, 134, 171)
    pdf.cell(0, 8, "DESEMPENHO POR CATEGORIA", ln=True)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)

    headers = ["Categoria", "Faturamento (R$)", "Custo (R$)", "Lucro (R$)", "Margem %", "Qtd Vendas"]
    widths  = [40, 38, 35, 35, 25, 27]

    pdf.set_fill_color(46, 134, 171)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 9)
    for h, w in zip(headers, widths):
        pdf.cell(w, 8, h, border=0, fill=True, align="C")
    pdf.ln()

    pdf.set_text_color(30, 30, 30)
    for i, row in kpis["categoria_df"].iterrows():
        fill = i % 2 == 0
        pdf.set_fill_color(248, 249, 250) if fill else pdf.set_fill_color(255, 255, 255)
        pdf.set_font("Helvetica", "", 9)
        pdf.cell(40, 7, row["Categoria"],                   fill=fill, align="L")
        pdf.cell(38, 7, f"{row['Faturamento']:>12,.2f}",    fill=fill, align="R")
        pdf.cell(35, 7, f"{row['Custo_Total']:>12,.2f}",    fill=fill, align="R")
        pdf.cell(35, 7, f"{row['Lucro_Total']:>12,.2f}",    fill=fill, align="R")
        pdf.cell(25, 7, f"{row['Margem_Pct']:.1f}%",        fill=fill, align="C")
        pdf.cell(27, 7, str(int(row["Qtd_Vendas"])),         fill=fill, align="C")
        pdf.ln()
    pdf.ln(5)

    # ── Insights ──
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(46, 134, 171)
    pdf.cell(0, 8, "INSIGHTS PRINCIPAIS", ln=True)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(3)

    cat_top = kpis["categoria_df"].iloc[0]
    cat_low = kpis["categoria_df"].iloc[-1]

    insights = [
        f"• A categoria '{cat_top['Categoria']}' liderou o lucro com R$ {cat_top['Lucro_Total']:,.2f} e margem de {cat_top['Margem_Pct']:.1f}%.",
        f"• '{cat_low['Categoria']}' apresentou a menor margem ({cat_low['Margem_Pct']:.1f}%), indicando oportunidade de revisão de custos.",
        f"• O produto '{kpis['produto_top']}' foi o mais vendido, gerando R$ {kpis['produto_top_valor']:,.2f} em faturamento.",
        f"• A margem geral de {kpis['margem_geral']:.1f}% demonstra saúde financeira no período analisado.",
        f"• Software apresenta as maiores margens, sendo estratégico para maximização de lucro.",
    ]

    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(40, 40, 40)
    for ins in insights:
        pdf.multi_cell(0, 6, ins)
        pdf.ln(1)

    # ── Gráficos ──
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(46, 134, 171)
    pdf.cell(0, 8, "ANÁLISE VISUAL", ln=True)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(4)

    pdf.image(img_barras, x=10, w=185)
    pdf.ln(6)
    pdf.image(img_linhas, x=10, w=185)

    pdf.output(caminho)
    print(f"[✔] PDF exportado: {caminho}")
    return caminho


# ─────────────────────────────────────────────
# 5. PIPELINE PRINCIPAL
# ─────────────────────────────────────────────

def main():
    print("\n" + "="*50)
    print("  AUTOMAÇÃO DE RELATÓRIOS FINANCEIROS — 2024")
    print("="*50 + "\n")

    df       = gerar_dados_csv("vendas_mensais.csv")
    kpis     = processar_dados(df)
    img_b    = criar_grafico_barras(kpis["categoria_df"])
    img_l    = criar_grafico_linhas(kpis["mensal_df"])
    pdf_path = exportar_pdf(kpis, img_b, img_l)

    print(f"\n{'='*50}")
    print(f"  RELATÓRIO GERADO COM SUCESSO!")
    print(f"  Arquivo: {pdf_path}")
    print(f"{'='*50}\n")


if __name__ == "__main__":
    main()
